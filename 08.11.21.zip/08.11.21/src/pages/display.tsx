import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import {gql} from '@apollo/client';
import client from '../../apollo-client';
import { stringify } from 'querystring';
import {ApolloClient, InMemoryCache} from '@apollo/client'
import prisma from '../backend/database/client'
import { useState } from 'react';


const Display: NextPage = (props) => {
    const [input, setInput] = useState('');
    var dataStorage = [];
    const fetchData = () => {
        const options = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({searchInput: input})
          };
          
          const response = fetch('http://localhost:3000/api/computer', options)
          .then(response => response.json()
          .then(data => dataStorage = data));
          
    }

    
  return (


    <div className={styles.container}>
        <h1>Search A Computer</h1>
        <input onChange={(e) => setInput(e.target.value)} type="text" name="search" placeholder="search"></input>
        <button onClick={fetchData} type="button">Search</button>



        <div id="grid">
            <h1>And the bruisers... will barrel through any defences in their search of brains and blood!</h1>
         {
             
         }
        </div>
    </div>
  )
}

export async function getServerSideProps(){
    const options = {
        method: 'GET',
        headers: {'Content-Type': 'application/json'}
      };
    const data = await fetch('http://localhost:3000/api/computer', options);
    const computers = await data.json();
  return {
    props: {
        computers
    }
  }
}
export default Display;
