import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import {gql} from '@apollo/client';
import client from '../../apollo-client';
import { stringify } from 'querystring';
import {ApolloClient, InMemoryCache} from '@apollo/client'
import prisma from '../backend/database/client'
import { useState } from 'react';


const Home: NextPage = () => {
  const [price, setPrice] = useState('');
  const [model, setModel] = useState('');
  const [brand, setBrand] = useState('');

  const  handleClick = () => {
    const options = {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ brand: brand, price: parseInt(price), model: model})
    };

    const response = fetch('http://localhost:3000/api/computer', options);
    console.log(response);
    
    
  }

  return (
    <div className={styles.container}>
      <h1>Computer Shop</h1>
      <input type="number" onChange={(e) => setPrice(e.target.value)} name="price" placeholder="Price"></input>
      <br/>
      <input type="text" onChange={(e) => setModel(e.target.value)} name="model" placeholder="Model"></input>
      <br/>
      <input type="text" onChange={(e) => setBrand(e.target.value)} name="brand" placeholder="Brand"></input>
      <br/>
      <button onClick={handleClick} type="button">Create</button>
    </div>
  )
}

export async function getServerSideProps(){
  
  return {
    props: {}
  }
}
export default Home;
