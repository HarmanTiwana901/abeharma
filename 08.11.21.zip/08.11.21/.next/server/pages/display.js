/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/display";
exports.ids = ["pages/display"];
exports.modules = {

/***/ "./src/styles/Home.module.css":
/*!************************************!*\
  !*** ./src/styles/Home.module.css ***!
  \************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"Home_container__sDexO\",\n\t\"main\": \"Home_main__1gTMt\",\n\t\"footer\": \"Home_footer__34ULc\",\n\t\"title\": \"Home_title__38XO6\",\n\t\"description\": \"Home_description__p2VX9\",\n\t\"code\": \"Home_code__7lt7E\",\n\t\"grid\": \"Home_grid__2Clz5\",\n\t\"card\": \"Home_card__2kgLM\",\n\t\"logo\": \"Home_logo__qxZJS\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL0hvbWUubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8wOC4xMS4yMS8uL3NyYy9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzPzU5NzQiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwiY29udGFpbmVyXCI6IFwiSG9tZV9jb250YWluZXJfX3NEZXhPXCIsXG5cdFwibWFpblwiOiBcIkhvbWVfbWFpbl9fMWdUTXRcIixcblx0XCJmb290ZXJcIjogXCJIb21lX2Zvb3Rlcl9fMzRVTGNcIixcblx0XCJ0aXRsZVwiOiBcIkhvbWVfdGl0bGVfXzM4WE82XCIsXG5cdFwiZGVzY3JpcHRpb25cIjogXCJIb21lX2Rlc2NyaXB0aW9uX19wMlZYOVwiLFxuXHRcImNvZGVcIjogXCJIb21lX2NvZGVfXzdsdDdFXCIsXG5cdFwiZ3JpZFwiOiBcIkhvbWVfZ3JpZF9fMkNsejVcIixcblx0XCJjYXJkXCI6IFwiSG9tZV9jYXJkX18ya2dMTVwiLFxuXHRcImxvZ29cIjogXCJIb21lX2xvZ29fX3F4WkpTXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/styles/Home.module.css\n");

/***/ }),

/***/ "./src/pages/display.tsx":
/*!*******************************!*\
  !*** ./src/pages/display.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/Home.module.css */ \"./src/styles/Home.module.css\");\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nconst Display = ()=>{\n    const { 0: input , 1: setInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');\n    var dataStorage = [];\n    const fetchData = ()=>{\n        const options = {\n            method: 'POST',\n            headers: {\n                'Content-Type': 'application/json'\n            },\n            body: JSON.stringify({\n                searchInput: input\n            })\n        };\n        const response1 = fetch('http://localhost:3000/api/computer', options).then((response)=>response.json().then((data)=>dataStorage = data\n            )\n        );\n    };\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(\"div\", {\n        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2___default().container),\n        __source: {\n            fileName: \"C:\\\\Users\\\\Harman\\\\Desktop\\\\quiz32107\\\\abbeharman\\\\08.11.21\\\\src\\\\pages\\\\display.tsx\",\n            lineNumber: 33,\n            columnNumber: 5\n        },\n        __self: undefined,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"h1\", {\n                __source: {\n                    fileName: \"C:\\\\Users\\\\Harman\\\\Desktop\\\\quiz32107\\\\abbeharman\\\\08.11.21\\\\src\\\\pages\\\\display.tsx\",\n                    lineNumber: 34,\n                    columnNumber: 9\n                },\n                __self: undefined,\n                children: \"Search A Computer\"\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"input\", {\n                onChange: (e)=>setInput(e.target.value)\n                ,\n                type: \"text\",\n                name: \"search\",\n                placeholder: \"search\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\Harman\\\\Desktop\\\\quiz32107\\\\abbeharman\\\\08.11.21\\\\src\\\\pages\\\\display.tsx\",\n                    lineNumber: 35,\n                    columnNumber: 9\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"button\", {\n                onClick: fetchData,\n                type: \"button\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\Harman\\\\Desktop\\\\quiz32107\\\\abbeharman\\\\08.11.21\\\\src\\\\pages\\\\display.tsx\",\n                    lineNumber: 36,\n                    columnNumber: 9\n                },\n                __self: undefined,\n                children: \"Search\"\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"div\", {\n                id: \"grid\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\Harman\\\\Desktop\\\\quiz32107\\\\abbeharman\\\\08.11.21\\\\src\\\\pages\\\\display.tsx\",\n                    lineNumber: 40,\n                    columnNumber: 9\n                },\n                __self: undefined\n            })\n        ]\n    }));\n};\nasync function getServerSideProps() {\n    const options = {\n        method: 'GET',\n        headers: {\n            'Content-Type': 'application/json'\n        }\n    };\n    const data = await fetch('http://localhost:3000/api/computer', options);\n    const computers = await data.json();\n    return {\n        props: {\n            computers\n        }\n    };\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Display);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvZGlzcGxheS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBRzhDO0FBTWQ7QUFHaEMsS0FBSyxDQUFDRSxPQUFPLE9BQW1CLENBQUM7SUFDN0IsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFFO0lBQ3JDLEdBQUcsQ0FBQ0ksV0FBVyxHQUFHLENBQUMsQ0FBQztJQUNwQixLQUFLLENBQUNDLFNBQVMsT0FBUyxDQUFDO1FBQ3JCLEtBQUssQ0FBQ0MsT0FBTyxHQUFHLENBQUM7WUFDYkMsTUFBTSxFQUFFLENBQU07WUFDZEMsT0FBTyxFQUFFLENBQUM7Z0JBQUEsQ0FBYyxlQUFFLENBQWtCO1lBQUEsQ0FBQztZQUM3Q0MsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDQztnQkFBQUEsV0FBVyxFQUFFVixLQUFLO1lBQUEsQ0FBQztRQUMzQyxDQUFDO1FBRUQsS0FBSyxDQUFDVyxTQUFRLEdBQUdDLEtBQUssQ0FBQyxDQUFvQyxxQ0FBRVIsT0FBTyxFQUNuRVMsSUFBSSxFQUFDRixRQUFRLEdBQUlBLFFBQVEsQ0FBQ0csSUFBSSxHQUM5QkQsSUFBSSxFQUFDRSxJQUFJLEdBQUliLFdBQVcsR0FBR2EsSUFBSTs7O0lBRXRDLENBQUM7SUFHSCxNQUFNLHVFQUdIQyxDQUFHO1FBQUNDLFNBQVMsRUFBRXBCLDBFQUFnQjs7Ozs7Ozs7aUZBQzNCc0IsQ0FBRTs7Ozs7OzswQkFBQyxDQUFpQjs7aUZBQ3BCbkIsQ0FBSztnQkFBQ29CLFFBQVEsR0FBR0MsQ0FBQyxHQUFLcEIsUUFBUSxDQUFDb0IsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7O2dCQUFHQyxJQUFJLEVBQUMsQ0FBTTtnQkFBQ0MsSUFBSSxFQUFDLENBQVE7Z0JBQUNDLFdBQVcsRUFBQyxDQUFROzs7Ozs7OztpRkFDL0ZDLENBQU07Z0JBQUNDLE9BQU8sRUFBRXpCLFNBQVM7Z0JBQUVxQixJQUFJLEVBQUMsQ0FBUTs7Ozs7OzswQkFBQyxDQUFNOztpRkFJL0NSLENBQUc7Z0JBQUNhLEVBQUUsRUFBQyxDQUFNOzs7Ozs7Ozs7O0FBS3RCLENBQUM7QUFFTSxlQUFlQyxrQkFBa0IsR0FBRSxDQUFDO0lBQ3ZDLEtBQUssQ0FBQzFCLE9BQU8sR0FBRyxDQUFDO1FBQ2JDLE1BQU0sRUFBRSxDQUFLO1FBQ2JDLE9BQU8sRUFBRSxDQUFDO1lBQUEsQ0FBYyxlQUFFLENBQWtCO1FBQUEsQ0FBQztJQUMvQyxDQUFDO0lBQ0gsS0FBSyxDQUFDUyxJQUFJLEdBQUcsS0FBSyxDQUFDSCxLQUFLLENBQUMsQ0FBb0MscUNBQUVSLE9BQU87SUFDdEUsS0FBSyxDQUFDMkIsU0FBUyxHQUFHLEtBQUssQ0FBQ2hCLElBQUksQ0FBQ0QsSUFBSTtJQUNuQyxNQUFNLENBQUMsQ0FBQztRQUNOa0IsS0FBSyxFQUFFLENBQUM7WUFDSkQsU0FBUztRQUNiLENBQUM7SUFDSCxDQUFDO0FBQ0gsQ0FBQztBQUNELGlFQUFlaEMsT0FBTyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vMDguMTEuMjEvLi9zcmMvcGFnZXMvZGlzcGxheS50c3g/NjRlYiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5leHRQYWdlIH0gZnJvbSAnbmV4dCdcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSdcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5pbXBvcnQge2dxbH0gZnJvbSAnQGFwb2xsby9jbGllbnQnO1xyXG5pbXBvcnQgY2xpZW50IGZyb20gJy4uLy4uL2Fwb2xsby1jbGllbnQnO1xyXG5pbXBvcnQgeyBzdHJpbmdpZnkgfSBmcm9tICdxdWVyeXN0cmluZyc7XHJcbmltcG9ydCB7QXBvbGxvQ2xpZW50LCBJbk1lbW9yeUNhY2hlfSBmcm9tICdAYXBvbGxvL2NsaWVudCdcclxuaW1wb3J0IHByaXNtYSBmcm9tICcuLi9iYWNrZW5kL2RhdGFiYXNlL2NsaWVudCdcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcblxyXG5cclxuY29uc3QgRGlzcGxheTogTmV4dFBhZ2UgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbaW5wdXQsIHNldElucHV0XSA9IHVzZVN0YXRlKCcnKTtcclxuICAgIHZhciBkYXRhU3RvcmFnZSA9IFtdO1xyXG4gICAgY29uc3QgZmV0Y2hEYXRhID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7J0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ30sXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtzZWFyY2hJbnB1dDogaW5wdXR9KVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9jb21wdXRlcicsIG9wdGlvbnMpXHJcbiAgICAgICAgICAudGhlbihyZXNwb25zZSA9PiByZXNwb25zZS5qc29uKClcclxuICAgICAgICAgIC50aGVuKGRhdGEgPT4gZGF0YVN0b3JhZ2UgPSBkYXRhKSk7XHJcbiAgICAgICAgICBcclxuICAgIH1cclxuXHJcbiAgICBcclxuICByZXR1cm4gKFxyXG5cclxuXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgICAgPGgxPlNlYXJjaCBBIENvbXB1dGVyPC9oMT5cclxuICAgICAgICA8aW5wdXQgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbnB1dChlLnRhcmdldC52YWx1ZSl9IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInNlYXJjaFwiIHBsYWNlaG9sZGVyPVwic2VhcmNoXCI+PC9pbnB1dD5cclxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2ZldGNoRGF0YX0gdHlwZT1cImJ1dHRvblwiPlNlYXJjaDwvYnV0dG9uPlxyXG5cclxuXHJcblxyXG4gICAgICAgIDxkaXYgaWQ9XCJncmlkXCI+XHJcbiAgICAgICAgIFxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCl7XHJcbiAgICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgaGVhZGVyczogeydDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbid9XHJcbiAgICAgIH07XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvY29tcHV0ZXInLCBvcHRpb25zKTtcclxuICAgIGNvbnN0IGNvbXB1dGVycyA9IGF3YWl0IGRhdGEuanNvbigpO1xyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczoge1xyXG4gICAgICAgIGNvbXB1dGVyc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5leHBvcnQgZGVmYXVsdCBEaXNwbGF5O1xyXG4iXSwibmFtZXMiOlsic3R5bGVzIiwidXNlU3RhdGUiLCJEaXNwbGF5IiwiaW5wdXQiLCJzZXRJbnB1dCIsImRhdGFTdG9yYWdlIiwiZmV0Y2hEYXRhIiwib3B0aW9ucyIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInNlYXJjaElucHV0IiwicmVzcG9uc2UiLCJmZXRjaCIsInRoZW4iLCJqc29uIiwiZGF0YSIsImRpdiIsImNsYXNzTmFtZSIsImNvbnRhaW5lciIsImgxIiwib25DaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJ0eXBlIiwibmFtZSIsInBsYWNlaG9sZGVyIiwiYnV0dG9uIiwib25DbGljayIsImlkIiwiZ2V0U2VydmVyU2lkZVByb3BzIiwiY29tcHV0ZXJzIiwicHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/display.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/display.tsx"));
module.exports = __webpack_exports__;

})();