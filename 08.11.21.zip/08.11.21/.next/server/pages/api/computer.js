"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/computer";
exports.ids = ["pages/api/computer"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "./src/pages/api/computer.ts":
/*!***********************************!*\
  !*** ./src/pages/api/computer.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\nasync function handler(req, res) {\n    if (req.method === 'POST') {\n        if (req.body.searchInput) {\n            const computer = await prisma.computer.findMany({\n                where: {\n                    brand: req.body.searchInput\n                }\n            });\n            res.status(200).json(computer);\n            console.log('Data Read:');\n            console.log(computer);\n        } else {\n            const computer = await prisma.computer.create({\n                data: {\n                    brand: req.body.brand,\n                    model: req.body.model,\n                    price: req.body.price\n                }\n            });\n            res.status(200).json(computer);\n            console.log('Data Sent: ');\n        }\n    } else if (req.method === 'GET') {\n        const computer = await prisma.computer.findMany({\n            select: {\n                brand: true,\n                model: true,\n                price: true,\n                id: true\n            }\n        });\n        res.status(200).json(computer);\n        console.log('Data Read (GET):');\n        console.log(computer);\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvYXBpL2NvbXB1dGVyLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUU2QztBQUM3QyxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNELHdEQUFZO0FBZWhCLGVBQWVFLE9BQU8sQ0FBQ0MsR0FBbUIsRUFBRUMsR0FBeUMsRUFBRSxDQUFDO0lBR3JHLEVBQUUsRUFBQ0QsR0FBRyxDQUFDRSxNQUFNLEtBQUssQ0FBTSxPQUFFLENBQUM7UUFFekIsRUFBRSxFQUFDRixHQUFHLENBQUNHLElBQUksQ0FBQ0MsV0FBVyxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDQyxRQUFRLEdBQUcsS0FBSyxDQUFDUCxNQUFNLENBQUNPLFFBQVEsQ0FBQ0MsUUFBUSxDQUM3QyxDQUFDO2dCQUNDQyxLQUFLLEVBQUUsQ0FBQztvQkFDTkMsS0FBSyxFQUFFUixHQUFHLENBQUNHLElBQUksQ0FBQ0MsV0FBVztnQkFDN0IsQ0FBQztZQUNILENBQUM7WUFFSEgsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7WUFDN0JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQVk7WUFDeEJELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDUCxRQUFRO1FBQ3RCLENBQUMsTUFBTSxDQUFDO1lBQ04sS0FBSyxDQUFDQSxRQUFRLEdBQUcsS0FBSyxDQUFDUCxNQUFNLENBQUNPLFFBQVEsQ0FBQ1EsTUFBTSxDQUMzQyxDQUFDO2dCQUNDQyxJQUFJLEVBQUUsQ0FBQztvQkFDTE4sS0FBSyxFQUFFUixHQUFHLENBQUNHLElBQUksQ0FBQ0ssS0FBSztvQkFDckJPLEtBQUssRUFBRWYsR0FBRyxDQUFDRyxJQUFJLENBQUNZLEtBQUs7b0JBQ3JCQyxLQUFLLEVBQUVoQixHQUFHLENBQUNHLElBQUksQ0FBQ2EsS0FBSztnQkFDdkIsQ0FBQztZQUNILENBQUM7WUFFSGYsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7WUFDN0JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWE7UUFDM0IsQ0FBQztJQUNILENBQUMsTUFBTSxFQUFFLEVBQUNaLEdBQUcsQ0FBQ0UsTUFBTSxLQUFLLENBQUssTUFBRSxDQUFDO1FBQy9CLEtBQUssQ0FBQ0csUUFBUSxHQUFHLEtBQUssQ0FBQ1AsTUFBTSxDQUFDTyxRQUFRLENBQUNDLFFBQVEsQ0FDN0MsQ0FBQztZQUNDVyxNQUFNLEVBQUUsQ0FBQztnQkFDUFQsS0FBSyxFQUFFLElBQUk7Z0JBQ1hPLEtBQUssRUFBRSxJQUFJO2dCQUNYQyxLQUFLLEVBQUUsSUFBSTtnQkFDWEUsRUFBRSxFQUFFLElBQUk7WUFDVixDQUFDO1FBQ0gsQ0FBQztRQUVIakIsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7UUFDN0JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWtCO1FBQzlCRCxPQUFPLENBQUNDLEdBQUcsQ0FBQ1AsUUFBUTtJQUV0QixDQUFDO0FBTUQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovLzA4LjExLjIxLy4vc3JjL3BhZ2VzL2FwaS9jb21wdXRlci50cz9kYmE0Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIE5leHQuanMgQVBJIHJvdXRlIHN1cHBvcnQ6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL2FwaS1yb3V0ZXMvaW50cm9kdWN0aW9uXHJcbmltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnXHJcbmltcG9ydCB7IFByaXNtYUNsaWVudCB9IGZyb20gJ0BwcmlzbWEvY2xpZW50J1xyXG5jb25zdCBwcmlzbWEgPSBuZXcgUHJpc21hQ2xpZW50KCk7XHJcbnR5cGUgQ29tcHV0ZXIgPSB7XHJcbiBcclxuICBicmFuZDogc3RyaW5nO1xyXG4gIG1vZGVsOiBzdHJpbmc7XHJcbiAgcHJpY2U6IG51bWJlcjtcclxufVxyXG5cclxudHlwZSBCb2R5ID0ge1xyXG4gIFxyXG4gIGJyYW5kOiBzdHJpbmc7XHJcbiAgbW9kZWw6IHN0cmluZztcclxuICBwcmljZTogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcTogTmV4dEFwaVJlcXVlc3QsIHJlczogTmV4dEFwaVJlc3BvbnNlPENvbXB1dGVyfENvbXB1dGVyW10+KSB7XHJcblxyXG4gIFxyXG4gIGlmKHJlcS5tZXRob2QgPT09ICdQT1NUJykge1xyXG5cclxuICAgIGlmKHJlcS5ib2R5LnNlYXJjaElucHV0KSB7XHJcbiAgICAgIGNvbnN0IGNvbXB1dGVyID0gYXdhaXQgcHJpc21hLmNvbXB1dGVyLmZpbmRNYW55KFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgIGJyYW5kOiByZXEuYm9keS5zZWFyY2hJbnB1dFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICByZXMuc3RhdHVzKDIwMCkuanNvbihjb21wdXRlcik7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdEYXRhIFJlYWQ6Jyk7XHJcbiAgICAgIGNvbnNvbGUubG9nKGNvbXB1dGVyKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IGNvbXB1dGVyID0gYXdhaXQgcHJpc21hLmNvbXB1dGVyLmNyZWF0ZShcclxuICAgICAgICB7XHJcbiAgICAgICAgICBkYXRhOiB7ICAgICBcclxuICAgICAgICAgICAgYnJhbmQ6IHJlcS5ib2R5LmJyYW5kLFxyXG4gICAgICAgICAgICBtb2RlbDogcmVxLmJvZHkubW9kZWwsXHJcbiAgICAgICAgICAgIHByaWNlOiByZXEuYm9keS5wcmljZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICByZXMuc3RhdHVzKDIwMCkuanNvbihjb21wdXRlcik7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdEYXRhIFNlbnQ6ICcpXHJcbiAgICB9XHJcbiAgfSBlbHNlIGlmKHJlcS5tZXRob2QgPT09ICdHRVQnKSB7XHJcbiAgICBjb25zdCBjb21wdXRlciA9IGF3YWl0IHByaXNtYS5jb21wdXRlci5maW5kTWFueShcclxuICAgICAge1xyXG4gICAgICAgIHNlbGVjdDoge1xyXG4gICAgICAgICAgYnJhbmQ6IHRydWUsXHJcbiAgICAgICAgICBtb2RlbDogdHJ1ZSxcclxuICAgICAgICAgIHByaWNlOiB0cnVlLFxyXG4gICAgICAgICAgaWQ6IHRydWVcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKGNvbXB1dGVyKTtcclxuICAgIGNvbnNvbGUubG9nKCdEYXRhIFJlYWQgKEdFVCk6Jyk7XHJcbiAgICBjb25zb2xlLmxvZyhjb21wdXRlcik7XHJcbiAgICBcclxuICB9XHJcbiAgIFxyXG4gICAgXHJcbiAgICBcclxuXHJcbiAgICBcclxuICB9XHJcbiAgIl0sIm5hbWVzIjpbIlByaXNtYUNsaWVudCIsInByaXNtYSIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJib2R5Iiwic2VhcmNoSW5wdXQiLCJjb21wdXRlciIsImZpbmRNYW55Iiwid2hlcmUiLCJicmFuZCIsInN0YXR1cyIsImpzb24iLCJjb25zb2xlIiwibG9nIiwiY3JlYXRlIiwiZGF0YSIsIm1vZGVsIiwicHJpY2UiLCJzZWxlY3QiLCJpZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/api/computer.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/api/computer.ts"));
module.exports = __webpack_exports__;

})();